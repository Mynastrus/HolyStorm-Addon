local addonVersion="2.1.0"
local HolyStorm=LibStub("AceAddon-3.0"):GetAddon("Holy_Storm");local L=LibStub("AceLocale-3.0"):GetLocale("Holy_Storm_Delves")
local metadata={displayName=L["DISPLAY_NAME"],internalName="delves",version=addonVersion,category="optional",description=L["DESCRIPTION"],permissions={"delves-read","sync-send"},dependencies={"core","ui"},enabledByDefault=true}
local function unknown(reason)return{status="unknown",reason=reason or"not_exposed_by_blizzard_api"}end
HolyStorm:RegisterOptionalModule("Delves",metadata,function(Module)
 HolyStorm:ApplyModuleMetadata(Module,metadata)
 function Module:GetCharacterSnapshot(guid)return HolyStorm.Data.CharacterStore:GetBlock(guid,"delves")end
 function Module:Collect()
  local d,w=C_DelvesUI,C_WeeklyRewards;if not d or not w or not w.GetActivities then return nil end;local enum=Enum and Enum.WeeklyRewardChestThresholdType;local world=enum and enum.World
  local s={seasonNumber=d.GetCurrentDelvesSeasonNumber and d.GetCurrentDelvesSeasonNumber(),week=date("%G-W%V"),activities={},completed={},bountiful=unknown(),nemesis=unknown(),treasureMap=unknown(),flute=unknown(),crestProgress=unknown(),limitedRewards=unknown(),updatedAt=HolyStorm.Utils.Now(),snapshotVersion=2}
  for _,a in ipairs(w.GetActivities(world)or{})do s.activities[#s.activities+1]={id=a.id,index=a.index,type=a.type,progress=a.progress,threshold=a.threshold,level=a.level,rewardLevel=a.rewardLevel};if(a.progress or 0)>=(a.threshold or math.huge)then s.completed[#s.completed+1]=a.index end end
  s.weeklyProgress=#s.completed;s.weeklyRewardAvailable=w.HasAvailableRewards and w.HasAvailableRewards()or false
  local companion=d.GetCompanionInfoForActivePlayer and d.GetCompanionInfoForActivePlayer();if companion and companion>0 then s.companion={id=companion,pdeId=d.GetPlayerCompanionPDEID and d.GetPlayerCompanionPDEID(companion),factionId=d.GetFactionForCompanion and d.GetFactionForCompanion(companion),roleNodeId=d.GetRoleNodeForCompanion and d.GetRoleNodeForCompanion(companion),traitTreeId=d.GetTraitTreeForCompanion and d.GetTraitTreeForCompanion(companion),level=unknown(),role=unknown(),abilities=unknown()}else s.companion=unknown("no_active_companion_data")end;return s
 end
 function Module:Validate(s)if type(s)~="table"then return false,"Delves API unavailable"end;if not tonumber(s.seasonNumber)then return false,"season unavailable"end;if type(s.activities)~="table"then return false,"weekly activities unavailable"end;return true end
 function Module:Commit(s)local guid=UnitGUID("player");return HolyStorm.Data.CharacterStore:SetDelves(guid,s,{updatedAt=s.updatedAt,updatedBy=guid},"blizzard")end
 function Module:Queue(sync)return HolyStorm.Snapshots:Queue("delves",function()return Module:Collect()end,function(s)return Module:Validate(s)end,function(s,f)return Module:Commit(s,f,sync)end,{source="Delves",delay=1,retryDelay=2.5,priority=6})end
 function Module:RefreshPage()if not self.page or not self.page:IsShown()then return end;local r=HolyStorm.Data.CharacterStore:Get(UnitGUID("player"));local d=r and r.delves;local lines={};for _,a in ipairs(d and d.activities or{})do lines[#lines+1]=string.format(L["ACTIVITY_FORMAT"],a.progress or 0,a.threshold or 0,a.level or 0)end;self.text:SetText(#lines>0 and table.concat(lines,"\n")or L["NO_DATA"])end
 function Module:OnInitialize()HolyStorm:RegisterCapability("Delves","character.scan.delves",function(_,sync)return Module:Queue(sync)end);HolyStorm:RegisterCapability("Delves","character.scan.additional",function(_,sync)return Module:Queue(sync)end)end
 function Module:OnEnable()if not C_DelvesUI or not C_WeeklyRewards then self:Disable();return end;for _,ev in ipairs({"WEEKLY_REWARDS_UPDATE","PLAYER_ENTERING_WORLD","DELVES_ACCOUNT_DATA_ELEMENT_CHANGED","ACTIVE_DELVE_DATA_UPDATE"})do local event=ev;HolyStorm.Events:Register(event,"delves",function()Module:Queue(true)end)end end
 function Module:OnDisable()HolyStorm.Events:UnregisterOwner("delves");HolyStorm.Snapshots:Cancel("delves")end
end)
